package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.HotspotRepository
import com.example.engine.MikrotikTemplateEngine
import com.example.model.HotspotVariables
import com.example.model.SessionState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AL-BARQ NET", appName)
    }

    @Test
    fun testBuiltinDemoRepository() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = HotspotRepository(context)
        val files = repo.loadBuiltinDemo()

        assertTrue(files.any { it.name == "login.html" })
        assertTrue(files.any { it.name == "status.html" })
        assertTrue(files.any { it.name == "logout.html" })

        val loginContent = repo.readFileContent("login.html")
        assertNotNull(loginContent)
        assertTrue(loginContent!!.contains("AL-BARQ NET"))
    }

    @Test
    fun testTemplateEngineSubstitution() {
        val engine = MikrotikTemplateEngine()
        val vars = HotspotVariables(
            ip = "192.168.88.50",
            username = "barq_tester",
            error = "Invalid password"
        )

        val template = "IP: $(ip), User: $(username), $(if error)Err: $(error)$(endif)"
        val result = engine.processHtml(template, vars, SessionState.LOGGED_OUT)

        assertTrue(result.processedContent.contains("IP: 192.168.88.50"))
        assertTrue(result.processedContent.contains("User: barq_tester"))
        assertTrue(result.processedContent.contains("Err: Invalid password"))
    }

    @Test
    fun testTemplateEngineIfElseBranch() {
        val engine = MikrotikTemplateEngine()
        val varsNoError = HotspotVariables(error = "")

        val template = "$(if error)HasError$(else)NoError$(endif)"
        val result = engine.processHtml(template, varsNoError, SessionState.LOGGED_OUT)

        assertEquals("NoError", result.processedContent)
    }
}
