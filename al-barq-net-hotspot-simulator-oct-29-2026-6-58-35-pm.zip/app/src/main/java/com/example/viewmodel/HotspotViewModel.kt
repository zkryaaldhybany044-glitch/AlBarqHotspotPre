package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.HotspotRepository
import com.example.engine.MikrotikTemplateEngine
import com.example.model.DevicePreset
import com.example.model.DiagnosticCategory
import com.example.model.DiagnosticItem
import com.example.model.DiagnosticSeverity
import com.example.model.HotspotFileInfo
import com.example.model.HotspotVariables
import com.example.model.LoginOutcome
import com.example.model.PreviewOrientation
import com.example.model.SessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HotspotUiState(
    val folderName: String = "النموذج التجريبي لشبكة البرق نت",
    val folderUri: Uri? = null,
    val isBuiltinDemo: Boolean = true,
    val fileTree: List<HotspotFileInfo> = emptyList(),
    val selectedPage: String = "login.html",
    val variables: HotspotVariables = HotspotVariables(),
    val sessionState: SessionState = SessionState.LOGGED_OUT,
    val loginOutcome: LoginOutcome = LoginOutcome.SUCCESS,
    val simulatedErrorMessage: String = "اسم المستخدم أو كلمة المرور غير صحيحة",
    val diagnostics: List<DiagnosticItem> = emptyList(),
    val devicePreset: DevicePreset = DevicePreset.STANDARD_PHONE,
    val orientation: PreviewOrientation = PreviewOrientation.PORTRAIT,
    val zoomPercent: Int = 100,
    val reloadTrigger: Long = 0L,
    val isLoading: Boolean = false,
    val userNotice: String? = null
)

class HotspotViewModel(application: Application) : AndroidViewModel(application) {

    val repository = HotspotRepository(application.applicationContext)
    val templateEngine = MikrotikTemplateEngine()

    private val _uiState = MutableStateFlow(HotspotUiState())
    val uiState: StateFlow<HotspotUiState> = _uiState.asStateFlow()

    init {
        loadDemoProject()
    }

    fun loadDemoProject() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, userNotice = null) }
            val files = repository.loadBuiltinDemo()
            _uiState.update {
                it.copy(
                    folderName = repository.getFolderName(),
                    folderUri = null,
                    isBuiltinDemo = true,
                    fileTree = files,
                    selectedPage = "login.html",
                    isLoading = false,
                    userNotice = "تم تحميل النموذج التجريبي لشبكة البرق نت بنجاح."
                )
            }
            triggerReload()
        }
    }

    fun onFolderSelected(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, userNotice = null) }
            try {
                val (name, files) = repository.setFolderUri(uri)
                // Auto select login.html if exists, otherwise first html file
                val htmlFile = findFirstHtmlFile(files) ?: "login.html"

                _uiState.update {
                    it.copy(
                        folderName = name,
                        folderUri = uri,
                        isBuiltinDemo = false,
                        fileTree = files,
                        selectedPage = htmlFile,
                        isLoading = false,
                        userNotice = "تم فتح المجلد: $name بنجاح."
                    )
                }
                triggerReload()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        userNotice = "فشل فتح المجلد: ${e.message}"
                    )
                }
            }
        }
    }

    private fun findFirstHtmlFile(list: List<HotspotFileInfo>): String? {
        val login = list.firstOrNull { it.name.equals("login.html", ignoreCase = true) }
        if (login != null) return login.path

        for (item in list) {
            if (item.isHtml) return item.path
            if (item.isDirectory) {
                val sub = findFirstHtmlFile(item.children)
                if (sub != null) return sub
            }
        }
        return null
    }

    fun selectPage(path: String) {
        _uiState.update {
            it.copy(
                selectedPage = path,
                reloadTrigger = it.reloadTrigger + 1
            )
        }
    }

    fun setSessionState(state: SessionState, errorMsg: String? = null) {
        _uiState.update { current ->
            val updatedVars = if (errorMsg != null) {
                current.variables.copy(error = errorMsg)
            } else if (state == SessionState.LOGGED_IN) {
                current.variables.copy(error = "")
            } else {
                current.variables
            }
            current.copy(
                sessionState = state,
                variables = updatedVars,
                reloadTrigger = current.reloadTrigger + 1
            )
        }
    }

    fun setLoginOutcome(outcome: LoginOutcome) {
        _uiState.update { it.copy(loginOutcome = outcome) }
    }

    fun setSimulatedErrorMessage(msg: String) {
        _uiState.update {
            it.copy(
                simulatedErrorMessage = msg,
                variables = it.variables.copy(error = msg)
            )
        }
    }

    fun updateVariables(newVars: HotspotVariables) {
        _uiState.update {
            it.copy(
                variables = newVars,
                reloadTrigger = it.reloadTrigger + 1,
                userNotice = "تم تحديث متغيرات المحاكاة."
            )
        }
    }

    fun resetVariablesToDefault() {
        _uiState.update {
            it.copy(
                variables = HotspotVariables(),
                reloadTrigger = it.reloadTrigger + 1,
                userNotice = "تمت استعادة المتغيرات الافتراضية."
            )
        }
    }

    fun addDiagnostic(item: DiagnosticItem) {
        _uiState.update { current ->
            // Prevent exact duplicates
            val exists = current.diagnostics.any {
                it.category == item.category && it.path == item.path && it.description == item.description
            }
            if (exists) current else current.copy(diagnostics = listOf(item) + current.diagnostics)
        }
    }

    fun clearDiagnostics() {
        _uiState.update { it.copy(diagnostics = emptyList()) }
    }

    fun setDevicePreset(preset: DevicePreset) {
        _uiState.update { it.copy(devicePreset = preset) }
    }

    fun toggleOrientation() {
        _uiState.update {
            it.copy(
                orientation = if (it.orientation == PreviewOrientation.PORTRAIT) {
                    PreviewOrientation.LANDSCAPE
                } else {
                    PreviewOrientation.PORTRAIT
                }
            )
        }
    }

    fun setZoom(percent: Int) {
        _uiState.update { it.copy(zoomPercent = percent.coerceIn(50, 200)) }
    }

    fun triggerReload() {
        _uiState.update { it.copy(reloadTrigger = it.reloadTrigger + 1) }
    }

    fun clearNotice() {
        _uiState.update { it.copy(userNotice = null) }
    }

    fun generateReportText(): String {
        val state = _uiState.value
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val dateStr = sdf.format(Date())

        val sb = StringBuilder()
        sb.appendLine("==========================================")
        sb.appendLine("تقرير فحص وتشخيص صفحة الهوتسبوت - شبكة البرق نت")
        sb.appendLine("التاريخ: $dateStr")
        sb.appendLine("المشروع: ${state.folderName}")
        sb.appendLine("الصفحة المحددة: ${state.selectedPage}")
        sb.appendLine("حالة الجلسة: ${if (state.sessionState == SessionState.LOGGED_IN) "مسجل الدخول" else "غير مسجل"}")
        sb.appendLine("==========================================")
        sb.appendLine()

        val errors = state.diagnostics.filter { it.severity == DiagnosticSeverity.ERROR }
        val warnings = state.diagnostics.filter { it.severity == DiagnosticSeverity.WARNING }
        val infos = state.diagnostics.filter { it.severity == DiagnosticSeverity.INFO }

        sb.appendLine("ملخص الفحص:")
        sb.appendLine("• الأخطاء الجسيمة (Errors): ${errors.size}")
        sb.appendLine("• التحذيرات (Warnings): ${warnings.size}")
        sb.appendLine("• الملاحظات والمعلومات (Info): ${infos.size}")
        sb.appendLine()
        sb.appendLine("----------------- التفاصيل -----------------")

        if (state.diagnostics.isEmpty()) {
            sb.appendLine("لم يتم رصد أي أخطاء أو ملفات مفقودة في الصفحة حتى الآن.")
        } else {
            state.diagnostics.forEachIndexed { i, item ->
                val icon = when (item.severity) {
                    DiagnosticSeverity.ERROR -> "[خطأ]"
                    DiagnosticSeverity.WARNING -> "[تحذير]"
                    DiagnosticSeverity.INFO -> "[ملاحظة]"
                }
                sb.appendLine("${i + 1}. $icon ${item.title}")
                sb.appendLine("   المسار: ${item.path}")
                if (item.lineNumber != null) sb.appendLine("   السطر: ${item.lineNumber}")
                sb.appendLine("   التفاصيل: ${item.description}")
                sb.appendLine("   اقتراح الحل: ${item.suggestion}")
                sb.appendLine()
            }
        }
        sb.appendLine("==========================================")
        sb.appendLine("تم التوليد بواسطة تطبيق AL-BARQ NET Hotspot Simulator")
        return sb.toString()
    }
}
