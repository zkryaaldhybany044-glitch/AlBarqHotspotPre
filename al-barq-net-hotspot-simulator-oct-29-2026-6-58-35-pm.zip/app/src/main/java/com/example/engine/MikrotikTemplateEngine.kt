package com.example.engine

import com.example.model.DiagnosticCategory
import com.example.model.DiagnosticItem
import com.example.model.DiagnosticSeverity
import com.example.model.HotspotVariables
import com.example.model.SessionState
import java.net.URLEncoder

/**
 * MikroTik RouterOS Hotspot Template Engine.
 * Evaluates conditionals $(if ...), $(elif ...), $(else), $(endif)
 * and replaces template variables $(var-name).
 */
class MikrotikTemplateEngine {

    data class ProcessResult(
        val processedContent: String,
        val unresolvedVariables: List<String>,
        val diagnostics: List<DiagnosticItem>
    )

    fun processHtml(
        rawContent: String,
        variables: HotspotVariables,
        sessionState: SessionState,
        sourceFile: String = "unknown.html"
    ): ProcessResult {
        val diagnostics = mutableListOf<DiagnosticItem>()

        // Step 1: Evaluate conditional directives $(if ...)...$(endif)
        val afterConditionals = try {
            evaluateConditionals(rawContent, variables, sessionState)
        } catch (e: Exception) {
            diagnostics.add(
                DiagnosticItem(
                    severity = DiagnosticSeverity.WARNING,
                    category = DiagnosticCategory.TEMPLATE_CONDITION,
                    title = "خطأ في تحليل شروط MikroTik",
                    path = sourceFile,
                    description = "تعذر تقييم بعض بنى $(if ...): ${e.message}",
                    suggestion = "تأكد من إغلاق كل شرط $(if) بـ $(endif) مقابلة."
                )
            )
            rawContent
        }

        // Step 2: Replace variables
        val (finalContent, unresolved) = substituteVariables(afterConditionals, variables, sessionState)

        if (unresolved.isNotEmpty()) {
            unresolved.distinct().forEach { v ->
                diagnostics.add(
                    DiagnosticItem(
                        severity = DiagnosticSeverity.INFO,
                        category = DiagnosticCategory.UNRESOLVED_VARIABLE,
                        title = "متغير غير مستبدل: \$$v",
                        path = sourceFile,
                        description = "بقي المتغير \$$v دون استبدال في المستند، ولم يتم التعرف على قيمته.",
                        suggestion = "يمكنك إضافة قيمة مخصصة له أو مراجعة متغيرات MikroTik المدعومة."
                    )
                )
            }
        }

        // Step 3: Check for hidden element patterns (e.g. style="visibility: hidden" or display:none)
        val hiddenRegex = Regex("""(<[a-zA-Z0-9]+\s+[^>]*style\s*=\s*["'][^"']*(?:visibility\s*:\s*hidden|display\s*:\s*none)[^"']*["'][^>]*>)""", RegexOption.IGNORE_CASE)
        val hiddenMatches = hiddenRegex.findAll(finalContent).toList()
        if (hiddenMatches.isNotEmpty()) {
            diagnostics.add(
                DiagnosticItem(
                    severity = DiagnosticSeverity.INFO,
                    category = DiagnosticCategory.HIDDEN_ELEMENT,
                    title = "عناصر مخفية في كود الصفحة (${hiddenMatches.size})",
                    path = sourceFile,
                    description = "تم رصد ${hiddenMatches.size} عنصر ذو نمط إخفاء CSS (visibility:hidden أو display:none).",
                    suggestion = "تأكد من أن كود JavaScript الخاص بالصفحة يقوم بإظهارها عند الحاجة (مثل نتائج callback أو الإشعارات)."
                )
            )
        }

        return ProcessResult(finalContent, unresolved, diagnostics)
    }

    /**
     * Recursively evaluates $(if cond) ... $(elif cond) ... $(else) ... $(endif)
     */
    private fun evaluateConditionals(
        input: String,
        vars: HotspotVariables,
        sessionState: SessionState
    ): String {
        val ifTagRegex = Regex("""\$\(if\s+([^)]+)\)""")
        val match = ifTagRegex.find(input) ?: return input

        val startIf = match.range.first
        val conditionExpr = match.groupValues[1].trim()

        // Find the matching $(endif), taking nested $(if) into account
        var depth = 1
        var currIndex = match.range.last + 1
        var matchingEndif = -1
        val elseBlocks = mutableListOf<Pair<String, IntRange>>() // (condition/else, range)
        var lastBlockStart = currIndex
        var lastCondition = conditionExpr

        val tagRegex = Regex("""\$\((if\s+[^)]+|elif\s+[^)]+|else|endif)\)""")
        while (currIndex < input.length) {
            val nextTag = tagRegex.find(input, currIndex) ?: break
            val tagName = nextTag.groupValues[1].trim()

            if (tagName.startsWith("if")) {
                depth++
                currIndex = nextTag.range.last + 1
            } else if (tagName == "endif") {
                depth--
                if (depth == 0) {
                    matchingEndif = nextTag.range.last
                    elseBlocks.add(Pair(lastCondition, lastBlockStart until nextTag.range.first))
                    break
                }
                currIndex = nextTag.range.last + 1
            } else if (depth == 1 && tagName.startsWith("elif")) {
                val elifCond = tagName.substringAfter("elif").trim()
                elseBlocks.add(Pair(lastCondition, lastBlockStart until nextTag.range.first))
                lastCondition = elifCond
                lastBlockStart = nextTag.range.last + 1
                currIndex = nextTag.range.last + 1
            } else if (depth == 1 && tagName == "else") {
                elseBlocks.add(Pair(lastCondition, lastBlockStart until nextTag.range.first))
                lastCondition = "else"
                lastBlockStart = nextTag.range.last + 1
                currIndex = nextTag.range.last + 1
            } else {
                currIndex = nextTag.range.last + 1
            }
        }

        if (matchingEndif == -1) {
            // Unmatched if statement, return as-is
            return input
        }

        // Evaluate blocks
        var selectedContent = ""
        for ((cond, range) in elseBlocks) {
            val isTrue = if (cond == "else") true else evaluateExpression(cond, vars, sessionState)
            if (isTrue) {
                selectedContent = input.substring(range)
                break
            }
        }

        // Recursively evaluate inner content
        val processedInner = evaluateConditionals(selectedContent, vars, sessionState)

        // Replace the whole block from startIf .. matchingEndif
        val prefix = input.substring(0, startIf)
        val suffix = input.substring(matchingEndif + 1)
        return prefix + processedInner + evaluateConditionals(suffix, vars, sessionState)
    }

    private fun evaluateExpression(
        expr: String,
        vars: HotspotVariables,
        sessionState: SessionState
    ): Boolean {
        val clean = expr.trim()

        if (clean.contains("==")) {
            val parts = clean.split("==").map { it.trim().trim('\'', '"') }
            if (parts.size == 2) {
                val leftVal = resolveVariableValue(parts[0], vars, sessionState)
                val rightVal = parts[1]
                return leftVal.equals(rightVal, ignoreCase = true)
            }
        }

        if (clean.contains("!=")) {
            val parts = clean.split("!=").map { it.trim().trim('\'', '"') }
            if (parts.size == 2) {
                val leftVal = resolveVariableValue(parts[0], vars, sessionState)
                val rightVal = parts[1]
                return !leftVal.equals(rightVal, ignoreCase = true)
            }
        }

        if (clean.startsWith("!")) {
            val inner = clean.substring(1).trim()
            return !evaluateExpression(inner, vars, sessionState)
        }

        // Truthy check for single identifier
        return when (clean.lowercase()) {
            "error" -> vars.error.isNotEmpty()
            "chap-id" -> vars.chapId.isNotEmpty()
            "chap-challenge" -> vars.chapChallenge.isNotEmpty()
            "trial" -> vars.trialEnabled
            "session-time-left" -> vars.sessionTimeLeft.isNotEmpty()
            "logged-in" -> sessionState == SessionState.LOGGED_IN
            "remain-bytes-total" -> vars.remainBytesTotal > 0
            "uptime" -> vars.uptime.isNotEmpty()
            "advert-pending" -> false
            else -> {
                val v = resolveVariableValue(clean, vars, sessionState)
                v.isNotEmpty() && v != "0" && !v.equals("false", ignoreCase = true)
            }
        }
    }

    private fun resolveVariableValue(
        name: String,
        vars: HotspotVariables,
        sessionState: SessionState
    ): String {
        return when (name.lowercase()) {
            "link-login-only" -> vars.linkLoginOnly
            "link-login" -> vars.linkLogin
            "link-orig" -> vars.linkOrig
            "link-logout" -> vars.linkLogout
            "link-status" -> vars.linkStatus
            "link-advert" -> vars.linkAdvert
            "link-redirect" -> vars.linkRedirect
            "error" -> vars.error
            "username" -> vars.username
            "ip" -> vars.ip
            "mac" -> vars.mac
            "hostname" -> vars.hostname
            "identity" -> vars.identity
            "server-name" -> vars.serverName
            "interface-name" -> vars.interfaceName
            "uptime" -> vars.uptime
            "session-time-left" -> vars.sessionTimeLeft
            "bytes-in" -> vars.bytesIn.toString()
            "bytes-out" -> vars.bytesOut.toString()
            "bytes-in-nice" -> vars.bytesInNice
            "bytes-out-nice" -> vars.bytesOutNice
            "remain-bytes-total" -> vars.remainBytesTotal.toString()
            "refresh-timeout" -> vars.refreshTimeout
            "chap-id" -> vars.chapId
            "chap-challenge" -> vars.chapChallenge
            "trial" -> if (vars.trialEnabled) "yes" else "no"
            "logged-in" -> if (sessionState == SessionState.LOGGED_IN) "yes" else "no"
            else -> ""
        }
    }

    private fun substituteVariables(
        input: String,
        vars: HotspotVariables,
        sessionState: SessionState
    ): Pair<String, List<String>> {
        val unresolved = mutableListOf<String>()

        fun encode(s: String): String = try {
            URLEncoder.encode(s, "UTF-8")
        } catch (_: Exception) {
            s
        }

        val map = mapOf(
            "link-login-only" to vars.linkLoginOnly,
            "link-login-only-esc" to encode(vars.linkLoginOnly),
            "link-login" to vars.linkLogin,
            "link-login-esc" to encode(vars.linkLogin),
            "link-orig" to vars.linkOrig,
            "link-orig-esc" to encode(vars.linkOrig),
            "link-logout" to vars.linkLogout,
            "link-logout-esc" to encode(vars.linkLogout),
            "link-status" to vars.linkStatus,
            "link-status-esc" to encode(vars.linkStatus),
            "link-advert" to vars.linkAdvert,
            "link-redirect" to vars.linkRedirect,
            "error" to vars.error,
            "username" to vars.username,
            "username-esc" to encode(vars.username),
            "ip" to vars.ip,
            "mac" to vars.mac,
            "mac-esc" to encode(vars.mac),
            "hostname" to vars.hostname,
            "identity" to vars.identity,
            "server-name" to vars.serverName,
            "interface-name" to vars.interfaceName,
            "uptime" to vars.uptime,
            "session-time-left" to vars.sessionTimeLeft,
            "bytes-in" to vars.bytesIn.toString(),
            "bytes-out" to vars.bytesOut.toString(),
            "bytes-in-nice" to vars.bytesInNice,
            "bytes-out-nice" to vars.bytesOutNice,
            "remain-bytes-total" to vars.remainBytesTotal.toString(),
            "refresh-timeout" to vars.refreshTimeout,
            "chap-id" to vars.chapId,
            "chap-challenge" to vars.chapChallenge,
            "trial" to if (vars.trialEnabled) "yes" else "no",
            "logged-in" to if (sessionState == SessionState.LOGGED_IN) "yes" else "no"
        )

        val varRegex = Regex("""\$\(([a-zA-Z0-9_\-]+)\)""")
        val replaced = varRegex.replace(input) { matchResult ->
            val key = matchResult.groupValues[1]
            val lower = key.lowercase()
            if (map.containsKey(lower)) {
                map[lower] ?: ""
            } else {
                unresolved.add(key)
                matchResult.value // leave untouched so it's detectable
            }
        }

        return Pair(replaced, unresolved)
    }
}
