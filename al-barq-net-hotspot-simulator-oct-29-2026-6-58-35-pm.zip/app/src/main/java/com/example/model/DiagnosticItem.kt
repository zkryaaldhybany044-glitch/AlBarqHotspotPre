package com.example.model

enum class DiagnosticSeverity {
    ERROR,
    WARNING,
    INFO
}

enum class DiagnosticCategory {
    HTTP_404,
    JS_CONSOLE,
    UNRESOLVED_VARIABLE,
    HIDDEN_ELEMENT,
    TEMPLATE_CONDITION,
    NETWORK_REQUEST
}

data class DiagnosticItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val severity: DiagnosticSeverity,
    val category: DiagnosticCategory,
    val title: String,
    val path: String,
    val lineNumber: Int? = null,
    val description: String,
    val suggestion: String
)

enum class DevicePreset(
    val titleAr: String,
    val widthDp: Int?,
    val heightDp: Int?
) {
    COMPACT_PHONE("هاتف صغير (360×640)", 360, 640),
    STANDARD_PHONE("هاتف قياسي (412×915)", 412, 915),
    LARGE_PHONE("هاتف كبير (480×1000)", 480, 1000),
    TABLET("جهاز لوحي (768×1024)", 768, 1024),
    FULL_SCREEN("ملء الشاشة", null, null)
}

enum class PreviewOrientation {
    PORTRAIT,
    LANDSCAPE
}
