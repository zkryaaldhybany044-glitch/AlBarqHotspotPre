package com.example.model

/**
 * MikroTik Hotspot simulation variables.
 * These correspond to RouterOS Hotspot template parameters.
 */
data class HotspotVariables(
    val ip: String = "10.5.50.88",
    val mac: String = "D4:6E:0E:5B:43:92",
    val username: String = "barq_guest",
    val hostname: String = "Barq-Android-Client",
    val identity: String = "AL-BARQ-NET-Core",
    val serverName: String = "AlBarq-Hotspot-01",
    val interfaceName: String = "bridge-hotspot",
    val linkLogin: String = "http://hotspot.local/login",
    val linkLoginOnly: String = "http://hotspot.local/login",
    val linkLogout: String = "http://hotspot.local/logout",
    val linkStatus: String = "http://hotspot.local/status",
    val linkOrig: String = "http://www.google.com",
    val linkAdvert: String = "http://hotspot.local/advert",
    val linkRedirect: String = "http://hotspot.local/redirect",
    val uptime: String = "1h 45m 12s",
    val sessionTimeLeft: String = "6h 14m 48s",
    val bytesIn: Long = 45210800L,
    val bytesOut: Long = 18450200L,
    val remainBytesTotal: Long = 1073741824L, // 1 GB
    val refreshTimeout: String = "60s",
    val chapId: String = "1",
    val chapChallenge: String = "a1b2c3d4e5f60718293a4b5c6d7e8f90",
    val trialEnabled: Boolean = true,
    val error: String = ""
) {
    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format("%.2f GiB", bytes.toDouble() / (1024 * 1024 * 1024))
            bytes >= 1024 * 1024 -> String.format("%.1f MiB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.1f KiB", bytes.toDouble() / 1024)
            else -> "$bytes B"
        }
    }

    val bytesInNice: String get() = formatBytes(bytesIn)
    val bytesOutNice: String get() = formatBytes(bytesOut)
    val remainBytesTotalNice: String get() = formatBytes(remainBytesTotal)
}

enum class SessionState {
    LOGGED_OUT,
    LOGGED_IN
}

enum class LoginOutcome {
    SUCCESS,
    FAILURE
}

data class HotspotFileInfo(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long = 0,
    val isHtml: Boolean = false,
    val children: List<HotspotFileInfo> = emptyList()
)
