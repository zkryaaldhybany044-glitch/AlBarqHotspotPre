package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppTopBar
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginTestScreen
import com.example.ui.screens.PreviewScreen
import com.example.ui.screens.VariablesScreen
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.HotspotViewModel

enum class HotspotTab(
    val titleAr: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
) {
    HOME("الرئيسية", Icons.Filled.Home, Icons.Outlined.Home),
    PREVIEW("المعاينة", Icons.Filled.Visibility, Icons.Outlined.Visibility),
    LOGIN_TEST("اختبار الدخول", Icons.Filled.PlayArrow, Icons.Outlined.PlayArrow),
    DIAGNOSTICS("التشخيص", Icons.Filled.Code, Icons.Outlined.Code),
    VARIABLES("المتغيرات", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: HotspotViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val context = LocalContext.current
                    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                    val snackbarHostState = remember { SnackbarHostState() }
                    var currentTab by remember { mutableStateOf(HotspotTab.HOME) }

                    // SAF Document Tree Launcher for picking hotspot folder
                    val folderPickerLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.OpenDocumentTree()
                    ) { uri: Uri? ->
                        if (uri != null) {
                            try {
                                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
                            } catch (_: Exception) {
                                // Some document providers don't support persistable flags
                            }
                            viewModel.onFolderSelected(uri)
                            Toast.makeText(context, "تم فتح المجلد بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    }

                    // Handle back press on sub-tabs
                    if (currentTab != HotspotTab.HOME) {
                        BackHandler {
                            currentTab = HotspotTab.HOME
                        }
                    }

                    // Show user notices in Snackbar
                    LaunchedEffect(uiState.userNotice) {
                        uiState.userNotice?.let { msg ->
                            snackbarHostState.showSnackbar(msg)
                            viewModel.clearNotice()
                        }
                    }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            AppTopBar(
                                currentFolderName = uiState.folderName,
                                sessionState = uiState.sessionState,
                                onRefresh = {
                                    viewModel.triggerReload()
                                    Toast.makeText(context, "تم تحديث المعاينة", Toast.LENGTH_SHORT).show()
                                }
                            )
                        },
                        bottomBar = {
                            NavigationBar(
                                containerColor = BarqNavySurface,
                                modifier = Modifier
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("app_navigation_bar")
                            ) {
                                HotspotTab.entries.forEach { tab ->
                                    val isSelected = currentTab == tab
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { currentTab = tab },
                                        icon = {
                                            if (tab == HotspotTab.DIAGNOSTICS && uiState.diagnostics.isNotEmpty()) {
                                                BadgedBox(
                                                    badge = {
                                                        Badge(
                                                            containerColor = BarqElectricCyan,
                                                            contentColor = Color(0xFF03071E)
                                                        ) {
                                                            Text(
                                                                text = "${uiState.diagnostics.size}",
                                                                fontSize = 9.sp
                                                            )
                                                        }
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                        contentDescription = tab.titleAr
                                                    )
                                                }
                                            } else {
                                                Icon(
                                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.titleAr
                                                )
                                            }
                                        },
                                        label = {
                                            Text(
                                                text = tab.titleAr,
                                                fontSize = 11.sp
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = BarqElectricCyan,
                                            selectedTextColor = BarqElectricCyan,
                                            indicatorColor = BarqRoyalBlue.copy(alpha = 0.35f),
                                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                                    )
                                }
                            }
                        },
                        snackbarHost = { SnackbarHost(snackbarHostState) }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (currentTab) {
                                HotspotTab.HOME -> {
                                    HomeScreen(
                                        uiState = uiState,
                                        onPickFolderClick = { folderPickerLauncher.launch(null) },
                                        onLoadDemoClick = {
                                            viewModel.loadDemoProject()
                                            Toast.makeText(context, "تم تحميل النموذج التجريبي", Toast.LENGTH_SHORT).show()
                                        },
                                        onNavigateToPreview = { path ->
                                            viewModel.selectPage(path)
                                            currentTab = HotspotTab.PREVIEW
                                        },
                                        onNavigateToDiagnostics = { currentTab = HotspotTab.DIAGNOSTICS },
                                        onNavigateToLoginTest = { currentTab = HotspotTab.LOGIN_TEST },
                                        onNavigateToVariables = { currentTab = HotspotTab.VARIABLES }
                                    )
                                }
                                HotspotTab.PREVIEW -> {
                                    PreviewScreen(
                                        viewModel = viewModel,
                                        uiState = uiState
                                    )
                                }
                                HotspotTab.LOGIN_TEST -> {
                                    LoginTestScreen(
                                        viewModel = viewModel,
                                        uiState = uiState,
                                        onNavigateToPreview = { currentTab = HotspotTab.PREVIEW }
                                    )
                                }
                                HotspotTab.DIAGNOSTICS -> {
                                    DiagnosticsScreen(
                                        viewModel = viewModel,
                                        uiState = uiState
                                    )
                                }
                                HotspotTab.VARIABLES -> {
                                    VariablesScreen(
                                        viewModel = viewModel,
                                        uiState = uiState
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
