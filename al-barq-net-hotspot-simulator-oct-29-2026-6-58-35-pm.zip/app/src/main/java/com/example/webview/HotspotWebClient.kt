package com.example.webview

import android.net.Uri
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.HotspotRepository
import com.example.engine.MikrotikTemplateEngine
import com.example.model.DiagnosticCategory
import com.example.model.DiagnosticItem
import com.example.model.DiagnosticSeverity
import com.example.model.HotspotVariables
import com.example.model.LoginOutcome
import com.example.model.SessionState
import java.io.ByteArrayInputStream

/**
 * Custom WebViewClient & WebChromeClient for simulating MikroTik Hotspot router environment.
 * Intercepts router routes (/login, /status, /logout, /login?var=callBack)
 * and resolves local assets (CSS, JS, images, fonts) on-the-fly.
 */
class HotspotWebClient(
    private val repository: HotspotRepository,
    private val templateEngine: MikrotikTemplateEngine,
    private val getVariables: () -> HotspotVariables,
    private val getSessionState: () -> SessionState,
    private val getLoginOutcome: () -> LoginOutcome,
    private val onSessionStateChanged: (SessionState, String?) -> Unit,
    private val onDiagnosticAdded: (DiagnosticItem) -> Unit
) : WebViewClient() {

    companion object {
        const val BASE_HOTSPOT_URL = "http://hotspot.local"
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return false
        val path = uri.path ?: ""
        val query = uri.query ?: ""

        // Handle navigation actions
        when {
            path.endsWith("/logout") || path.endsWith("/logout.html") -> {
                onSessionStateChanged(SessionState.LOGGED_OUT, null)
                view?.loadUrl("$BASE_HOTSPOT_URL/logout.html")
                return true
            }
            path.endsWith("/status") || path.endsWith("/status.html") -> {
                view?.loadUrl("$BASE_HOTSPOT_URL/status.html")
                return true
            }
            path.endsWith("/login") || path.endsWith("/login.html") -> {
                // Check if trial login or regular
                if (query.contains("username=T-")) {
                    onSessionStateChanged(SessionState.LOGGED_IN, null)
                    view?.loadUrl("$BASE_HOTSPOT_URL/status.html")
                    return true
                }
                view?.loadUrl("$BASE_HOTSPOT_URL/login.html")
                return true
            }
        }
        return false
    }

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val uri = request?.url ?: return null
        val fullUrl = uri.toString()
        val path = uri.path ?: "/"
        val query = uri.query ?: ""
        val method = request.method ?: "GET"

        // 1. Check for MikroTik callBack script query e.g. /login?var=callBack or ?callback=...
        if (query.contains("var=callBack") || query.contains("callback=")) {
            val callbackName = if (query.contains("var=callBack")) "callBack" else uri.getQueryParameter("callback") ?: "callBack"
            val vars = getVariables()
            val jsResponse = """
                if (typeof window['$callbackName'] === 'function') {
                    window['$callbackName']({
                        status: "ready",
                        ip: "${vars.ip}",
                        mac: "${vars.mac}",
                        identity: "${vars.identity}",
                        serverName: "${vars.serverName}"
                    });
                }
            """.trimIndent()

            onDiagnosticAdded(
                DiagnosticItem(
                    severity = DiagnosticSeverity.INFO,
                    category = DiagnosticCategory.NETWORK_REQUEST,
                    title = "محاكاة استجابة MikroTik Callback",
                    path = "$path?$query",
                    description = "تمت معالجة استدعاء $callbackName بنجاح وإرجاع بيانات الجلسة التجريبية.",
                    suggestion = "يعمل المسار بنجاح دون الحاجة لراوتر حقيقي."
                )
            )

            return WebResourceResponse(
                "application/javascript",
                "UTF-8",
                ByteArrayInputStream(jsResponse.toByteArray(Charsets.UTF_8))
            )
        }

        // 2. Handle POST /login or GET /login with login submission simulation
        if (method.equals("POST", ignoreCase = true) && (path.endsWith("/login") || path.endsWith("/login.html") || path.endsWith("/login-only"))) {
            val outcome = getLoginOutcome()
            return if (outcome == LoginOutcome.SUCCESS) {
                view?.post {
                    onSessionStateChanged(SessionState.LOGGED_IN, null)
                    view.loadUrl("$BASE_HOTSPOT_URL/status.html")
                }
                serveEmptyOk()
            } else {
                val simulatedError = getVariables().error.ifEmpty { "اسم المستخدم أو كلمة المرور غير صحيحة" }
                view?.post {
                    onSessionStateChanged(SessionState.LOGGED_OUT, simulatedError)
                    view.loadUrl("$BASE_HOTSPOT_URL/login.html")
                }
                serveEmptyOk()
            }
        }

        // 3. Handle HTML pages (login, status, logout, error, alogin)
        val targetHtml = when {
            path == "/" || path == "/login" || path.endsWith("/login.html") -> "login.html"
            path == "/status" || path.endsWith("/status.html") -> "status.html"
            path == "/logout" || path.endsWith("/logout.html") -> "logout.html"
            path == "/error" || path.endsWith("/error.html") -> "error.html"
            path == "/alogin" || path.endsWith("/alogin.html") -> "alogin.html"
            path.endsWith(".html", ignoreCase = true) -> path.removePrefix("/")
            else -> null
        }

        if (targetHtml != null) {
            val rawHtml = kotlinx.coroutines.runBlocking { repository.readFileContent(targetHtml) }
            if (rawHtml != null) {
                val vars = getVariables()
                val sessionState = getSessionState()
                val processed = templateEngine.processHtml(rawHtml, vars, sessionState, targetHtml)

                // Report any diagnostics found during template parsing
                processed.diagnostics.forEach { onDiagnosticAdded(it) }

                return WebResourceResponse(
                    "text/html",
                    "UTF-8",
                    ByteArrayInputStream(processed.processedContent.toByteArray(Charsets.UTF_8))
                )
            } else {
                // HTML file requested does not exist
                onDiagnosticAdded(
                    DiagnosticItem(
                        severity = DiagnosticSeverity.ERROR,
                        category = DiagnosticCategory.HTTP_404,
                        title = "صفحة مفقودة: $targetHtml",
                        path = targetHtml,
                        description = "لم يتم العثور على ملف $targetHtml داخل مجلد الهوتسبوت.",
                        suggestion = "تأكد من وجود الملف $targetHtml في المجلد الرئيسي لصفحات الهوتسبوت."
                    )
                )
                return serve404("الملف غير موجود: $targetHtml")
            }
        }

        // 4. Resolve static resources (CSS, JS, images, fonts, icons)
        val relativeAssetPath = path.removePrefix("/")
        val stream = repository.openFileInputStream(relativeAssetPath)
        if (stream != null) {
            val mime = repository.getMimeType(relativeAssetPath)
            return WebResourceResponse(mime, null, stream)
        }

        // Asset not found -> log 404 diagnostic!
        onDiagnosticAdded(
            DiagnosticItem(
                severity = DiagnosticSeverity.WARNING,
                category = DiagnosticCategory.HTTP_404,
                title = "مورد مفقود (404 Not Found)",
                path = path,
                description = "فشل تحميل المورد من المسار: $path",
                suggestion = "تحقق من وجود الملف في مجلد الهوتسبوت (مثل css/ أو js/ أو img/) وتطابق الاسم وحالة الأحرف."
            )
        )

        return serve404("Resource not found: $path")
    }

    private fun serveEmptyOk(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            200,
            "OK",
            emptyMap(),
            ByteArrayInputStream(ByteArray(0))
        )
    }

    private fun serve404(msg: String): WebResourceResponse {
        val html = "<html><body style='font-family:sans-serif;direction:rtl;padding:20px;color:#d00'><h3>خطأ 404 - لم يتم العثور على المورد</h3><p>$msg</p></body></html>"
        return WebResourceResponse(
            "text/html",
            "UTF-8",
            404,
            "Not Found",
            emptyMap(),
            ByteArrayInputStream(html.toByteArray(Charsets.UTF_8))
        )
    }
}

/**
 * WebChromeClient for capturing JavaScript console messages, warnings, and errors.
 */
class HotspotChromeClient(
    private val onDiagnosticAdded: (DiagnosticItem) -> Unit
) : WebChromeClient() {

    override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
        if (consoleMessage == null) return false

        val level = consoleMessage.messageLevel()
        val text = consoleMessage.message() ?: ""
        val source = consoleMessage.sourceId() ?: "inline"
        val line = consoleMessage.lineNumber()

        val severity = when (level) {
            ConsoleMessage.MessageLevel.ERROR -> DiagnosticSeverity.ERROR
            ConsoleMessage.MessageLevel.WARNING -> DiagnosticSeverity.WARNING
            else -> DiagnosticSeverity.INFO
        }

        // Filter out benign noise
        if (text.isNotBlank()) {
            val cleanSource = source.substringAfterLast("/")
            onDiagnosticAdded(
                DiagnosticItem(
                    severity = severity,
                    category = DiagnosticCategory.JS_CONSOLE,
                    title = "رسالة JavaScript ($level)",
                    path = "$cleanSource:$line",
                    lineNumber = line,
                    description = text,
                    suggestion = if (severity == DiagnosticSeverity.ERROR) {
                        "راجع كود JavaScript في $cleanSource عند السطر $line، وتأكد من تعريف الدوال والمتغيرات المستخدمة."
                    } else {
                        "تنبيه برمجي في سكربت الصفحة."
                    }
                )
            )
        }

        return true
    }
}
