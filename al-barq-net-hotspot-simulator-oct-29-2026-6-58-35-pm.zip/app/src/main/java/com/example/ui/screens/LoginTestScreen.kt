package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LoginOutcome
import com.example.model.SessionState
import com.example.ui.theme.BarqDanger
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqElectricGreen
import com.example.ui.theme.BarqLightningGold
import com.example.ui.theme.BarqNavyBorder
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.ui.theme.BarqWarning
import com.example.viewmodel.HotspotUiState
import com.example.viewmodel.HotspotViewModel

@Composable
fun LoginTestScreen(
    viewModel: HotspotViewModel,
    uiState: HotspotUiState,
    onNavigateToPreview: () -> Unit
) {
    var testUser by remember { mutableStateOf("barq_guest") }
    var testPassword by remember { mutableStateOf("123456") }
    var customErrorText by remember { mutableStateOf(uiState.simulatedErrorMessage) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Disclaimer Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = BarqElectricCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "تنبيه: هذا اختبار محلي آمن لمحاكاة تجربة المشترك والتحقق من سلوك الصفحة، ولا ينشئ جلسة حقيقية في راوتر MikroTik ولا يمنح اتصالاً فعلياً بالإنترنت.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                )
            }
        }

        // Credentials & Simulation Outcome Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "بيانات تسجيل الدخول التجريبية",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = BarqElectricCyan
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = testUser,
                    onValueChange = { testUser = it },
                    label = { Text("اسم المستخدم / رقم الكرت") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = BarqElectricCyan) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_username_field"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BarqElectricCyan,
                        unfocusedBorderColor = BarqNavyBorder,
                        focusedContainerColor = BarqNavyCard,
                        unfocusedContainerColor = BarqNavyCard
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = testPassword,
                    onValueChange = { testPassword = it },
                    label = { Text("كلمة المرور") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = BarqElectricCyan) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_password_field"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BarqElectricCyan,
                        unfocusedBorderColor = BarqNavyBorder,
                        focusedContainerColor = BarqNavyCard,
                        unfocusedContainerColor = BarqNavyCard
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "نتيجة المحاكاة المستهدفة:",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Outcome 1: Success
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.setLoginOutcome(LoginOutcome.SUCCESS) }
                        .background(if (uiState.loginOutcome == LoginOutcome.SUCCESS) BarqElectricGreen.copy(alpha = 0.1f) else Color.Transparent)
                        .padding(8.dp)
                ) {
                    RadioButton(
                        selected = uiState.loginOutcome == LoginOutcome.SUCCESS,
                        onClick = { viewModel.setLoginOutcome(LoginOutcome.SUCCESS) },
                        colors = RadioButtonDefaults.colors(selectedColor = BarqElectricGreen),
                        modifier = Modifier.testTag("radio_outcome_success")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "محاكاة تسجيل دخول ناجح (Success)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (uiState.loginOutcome == LoginOutcome.SUCCESS) BarqElectricGreen else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "ينقل المشترك تلقائياً إلى صفحة الحالة status.html مع تفعيل الجلسة",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Outcome 2: Failure
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.setLoginOutcome(LoginOutcome.FAILURE) }
                        .background(if (uiState.loginOutcome == LoginOutcome.FAILURE) BarqDanger.copy(alpha = 0.1f) else Color.Transparent)
                        .padding(8.dp)
                ) {
                    RadioButton(
                        selected = uiState.loginOutcome == LoginOutcome.FAILURE,
                        onClick = { viewModel.setLoginOutcome(LoginOutcome.FAILURE) },
                        colors = RadioButtonDefaults.colors(selectedColor = BarqDanger),
                        modifier = Modifier.testTag("radio_outcome_failure")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "محاكاة فشل تسجيل الدخول (Error)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (uiState.loginOutcome == LoginOutcome.FAILURE) BarqDanger else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "يُظهر رسالة الخطأ عبر \$(error) داخل صفحة login.html دون إدخال المستخدم",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (uiState.loginOutcome == LoginOutcome.FAILURE) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customErrorText,
                        onValueChange = {
                            customErrorText = it
                            viewModel.setSimulatedErrorMessage(it)
                        },
                        label = { Text("نص رسالة الخطأ للمشترك") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BarqDanger,
                            unfocusedBorderColor = BarqNavyBorder,
                            focusedContainerColor = BarqNavyCard,
                            unfocusedContainerColor = BarqNavyCard
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            if (uiState.loginOutcome == LoginOutcome.SUCCESS) {
                                viewModel.setSessionState(SessionState.LOGGED_IN, null)
                                viewModel.selectPage("status.html")
                            } else {
                                viewModel.setSessionState(SessionState.LOGGED_OUT, customErrorText)
                                viewModel.selectPage("login.html")
                            }
                            onNavigateToPreview()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("execute_login_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.loginOutcome == LoginOutcome.SUCCESS) BarqElectricCyan else BarqDanger,
                            contentColor = Color(0xFF030A16)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "بدء الاختبار بالمعاينة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    if (uiState.sessionState == SessionState.LOGGED_IN) {
                        OutlinedButton(
                            onClick = {
                                viewModel.setSessionState(SessionState.LOGGED_OUT, null)
                                viewModel.selectPage("logout.html")
                                onNavigateToPreview()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("execute_logout_btn"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BarqDanger)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = null,
                                tint = BarqDanger,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تسجيل الخروج",
                                color = BarqDanger,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Live Session Telemetry Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NetworkCheck,
                            contentDescription = null,
                            tint = BarqElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بيانات الجلسة المحاكاة",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (uiState.sessionState == SessionState.LOGGED_IN)
                                    BarqElectricGreen.copy(alpha = 0.2f)
                                else
                                    BarqNavyBorder
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (uiState.sessionState == SessionState.LOGGED_IN) "جلسة نشطة" else "غير مسجل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.sessionState == SessionState.LOGGED_IN) BarqElectricGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                SessionDetailRow("عنوان IP:", uiState.variables.ip)
                SessionDetailRow("عنوان MAC:", uiState.variables.mac)
                SessionDetailRow("المستخدم الحالي:", uiState.variables.username)
                SessionDetailRow("وقت الاتصال Uptime:", uiState.variables.uptime)
                SessionDetailRow("الوقت المتبقي:", uiState.variables.sessionTimeLeft)
                SessionDetailRow("البيانات المستهلكة:", "${uiState.variables.bytesInNice} تنزيل / ${uiState.variables.bytesOutNice} رفع")
                SessionDetailRow("الرصيد المتبقي:", uiState.variables.remainBytesTotalNice)
            }
        }

        // CHAP / MD5 Simulation Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = BarqLightningGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "محاكاة تشفير MikroTik CHAP MD5",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "عندما تستخدم الصفحة md5.js، يقوم الراوتر بتمرير chap-id و chap-challenge ليتم دمجها مع كلمة المرور ثم تشفيرها قبل الإرسال:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BarqNavyCard)
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "\$(chap-id): ${uiState.variables.chapId}",
                            fontSize = 11.sp,
                            color = BarqElectricCyan,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                        Text(
                            text = "\$(chap-challenge): ${uiState.variables.chapChallenge}",
                            fontSize = 11.sp,
                            color = BarqLightningGold,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SessionDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
