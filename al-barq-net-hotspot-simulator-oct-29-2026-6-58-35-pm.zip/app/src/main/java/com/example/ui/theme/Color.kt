package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AL-BARQ NET - Tech Palette
val BarqNavyBackground = Color(0xFF070E1F)
val BarqNavySurface = Color(0xFF0E1A38)
val BarqNavyCard = Color(0xFF14244B)
val BarqNavyBorder = Color(0xFF1E3A6E)

val BarqRoyalBlue = Color(0xFF0077B6)
val BarqElectricCyan = Color(0xFF00E5FF)
val BarqCyanSoft = Color(0xFF80EFFF)
val BarqLightningGold = Color(0xFFFFD166)
val BarqElectricGreen = Color(0xFF00F5D4)
val BarqDanger = Color(0xFFFF3366)
val BarqWarning = Color(0xFFFFBE0B)

val BarqTextPrimary = Color(0xFFF8FAFC)
val BarqTextSecondary = Color(0xFF94A3B8)
val BarqTextMuted = Color(0xFF64748B)

// Light theme alternatives
val BarqLightBackground = Color(0xFFF1F5F9)
val BarqLightSurface = Color(0xFFFFFFFF)
val BarqLightPrimary = Color(0xFF0284C7)
val BarqLightBorder = Color(0xFFCBD5E1)
