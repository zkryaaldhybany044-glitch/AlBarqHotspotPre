package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ImageNotSupported
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiagnosticCategory
import com.example.model.DiagnosticItem
import com.example.model.DiagnosticSeverity
import com.example.ui.theme.BarqDanger
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqElectricGreen
import com.example.ui.theme.BarqLightningGold
import com.example.ui.theme.BarqNavyBorder
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.ui.theme.BarqWarning
import com.example.viewmodel.HotspotUiState
import com.example.viewmodel.HotspotViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DiagnosticsScreen(
    viewModel: HotspotViewModel,
    uiState: HotspotUiState
) {
    val context = LocalContext.current
    var selectedCategoryFilter by remember { mutableStateOf<DiagnosticCategory?>(null) }
    var selectedSeverityFilter by remember { mutableStateOf<DiagnosticSeverity?>(null) }

    val filteredList = uiState.diagnostics.filter { item ->
        (selectedCategoryFilter == null || item.category == selectedCategoryFilter) &&
        (selectedSeverityFilter == null || item.severity == selectedSeverityFilter)
    }

    val errorCount = uiState.diagnostics.count { it.severity == DiagnosticSeverity.ERROR }
    val warningCount = uiState.diagnostics.count { it.severity == DiagnosticSeverity.WARNING }
    val notFoundCount = uiState.diagnostics.count { it.category == DiagnosticCategory.HTTP_404 }
    val jsErrorCount = uiState.diagnostics.count { it.category == DiagnosticCategory.JS_CONSOLE }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. KPI Summary Cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ملخص الفحص والتشخيص",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = BarqElectricCyan
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        maxItemsInEachRow = 2
                    ) {
                        DiagnosticMetricCard(
                            modifier = Modifier.weight(1f),
                            title = "أخطاء جسيمة",
                            count = errorCount,
                            color = BarqDanger
                        )
                        DiagnosticMetricCard(
                            modifier = Modifier.weight(1f),
                            title = "تحذيرات ومفقودات",
                            count = warningCount,
                            color = BarqWarning
                        )
                        DiagnosticMetricCard(
                            modifier = Modifier.weight(1f),
                            title = "ملفات مفقودة (404)",
                            count = notFoundCount,
                            color = Color(0xFFFF70A6)
                        )
                        DiagnosticMetricCard(
                            modifier = Modifier.weight(1f),
                            title = "رسائل JavaScript",
                            count = jsErrorCount,
                            color = BarqLightningGold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons: Copy & Share Report
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val report = viewModel.generateReportText()
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Hotspot Diagnostic Report", report)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "تم نسخ تقرير الفحص إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("copy_diagnostic_report_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BarqRoyalBlue,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("نسخ التقرير", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val report = viewModel.generateReportText()
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, report)
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "مشاركة تقرير فحص الهوتسبوت")
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("share_diagnostic_report_btn"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = BarqElectricCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("مشاركة", color = BarqElectricCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        IconButton(
                            onClick = { viewModel.clearDiagnostics() },
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(BarqNavyCard)
                                .testTag("clear_diagnostics_btn")
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح السجل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // 2. Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedCategoryFilter == null && selectedSeverityFilter == null,
                    onClick = {
                        selectedCategoryFilter = null
                        selectedSeverityFilter = null
                    },
                    label = { Text("الكل (${uiState.diagnostics.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BarqRoyalBlue,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = selectedCategoryFilter == DiagnosticCategory.HTTP_404,
                    onClick = {
                        selectedCategoryFilter = if (selectedCategoryFilter == DiagnosticCategory.HTTP_404) null else DiagnosticCategory.HTTP_404
                    },
                    label = { Text("مفقودات 404 ($notFoundCount)", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BarqDanger.copy(alpha = 0.2f),
                        selectedLabelColor = BarqDanger
                    )
                )

                FilterChip(
                    selected = selectedCategoryFilter == DiagnosticCategory.JS_CONSOLE,
                    onClick = {
                        selectedCategoryFilter = if (selectedCategoryFilter == DiagnosticCategory.JS_CONSOLE) null else DiagnosticCategory.JS_CONSOLE
                    },
                    label = { Text("JavaScript ($jsErrorCount)", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BarqLightningGold.copy(alpha = 0.2f),
                        selectedLabelColor = BarqLightningGold
                    )
                )
            }
        }

        // 3. Diagnostics List
        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BarqElectricGreen,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "لا توجد أخطاء مرصودة حالياً",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "يتم فحص الصفحة تلقائياً عند تشغيل المعاينة ورصد أي ملفات مفقودة أو أخطاء برمجية.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { item ->
                DiagnosticItemCard(item = item)
            }
        }
    }
}

@Composable
fun DiagnosticMetricCard(
    modifier: Modifier = Modifier,
    title: String,
    count: Int,
    color: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(BarqNavyCard)
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = "$count", fontSize = 20.sp, fontWeight = FontWeight.Black, color = color)
        }
    }
}

@Composable
fun DiagnosticItemCard(item: DiagnosticItem) {
    val (badgeText, badgeColor, icon) = when (item.severity) {
        DiagnosticSeverity.ERROR -> Triple("خطأ جسيم", BarqDanger, Icons.Default.Error)
        DiagnosticSeverity.WARNING -> Triple("تحذير", BarqWarning, Icons.Default.Warning)
        DiagnosticSeverity.INFO -> Triple("معلومة", BarqElectricCyan, Icons.Default.Code)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(badgeColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // File path & Line
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "المسار: ",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = item.path,
                    fontSize = 11.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    color = BarqElectricCyan
                )
                if (item.lineNumber != null) {
                    Text(
                        text = " (سطر ${item.lineNumber})",
                        fontSize = 11.sp,
                        color = BarqLightningGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = item.description,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Suggestion box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(BarqNavyCard)
                    .padding(8.dp)
            ) {
                Row {
                    Text(text = "💡 ", fontSize = 12.sp)
                    Text(
                        text = "اقتراح الحل: ${item.suggestion}",
                        fontSize = 11.sp,
                        color = BarqElectricGreen,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
