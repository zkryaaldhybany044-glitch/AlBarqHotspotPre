package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.view.ViewGroup
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CropLandscape
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Tablet
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.DevicePreset
import com.example.model.PreviewOrientation
import com.example.model.SessionState
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqElectricGreen
import com.example.ui.theme.BarqLightningGold
import com.example.ui.theme.BarqNavyBackground
import com.example.ui.theme.BarqNavyBorder
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.viewmodel.HotspotUiState
import com.example.viewmodel.HotspotViewModel
import com.example.webview.HotspotChromeClient
import com.example.webview.HotspotWebClient

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(
    viewModel: HotspotViewModel,
    uiState: HotspotUiState
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BarqNavyBackground)
    ) {
        // 1. Simulator Control Toolbar
        Surface(
            color = BarqNavySurface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                // First Row: Device Presets & Orientation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DevicePreset.entries.forEach { preset ->
                        FilterChip(
                            selected = uiState.devicePreset == preset,
                            onClick = { viewModel.setDevicePreset(preset) },
                            label = { Text(preset.titleAr, fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = when (preset) {
                                        DevicePreset.COMPACT_PHONE, DevicePreset.STANDARD_PHONE, DevicePreset.LARGE_PHONE -> Icons.Default.PhoneAndroid
                                        DevicePreset.TABLET -> Icons.Default.Tablet
                                        DevicePreset.FULL_SCREEN -> Icons.Default.Fullscreen
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BarqRoyalBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("preset_${preset.name}")
                        )
                    }

                    // Orientation Toggle
                    AssistChip(
                        onClick = { viewModel.toggleOrientation() },
                        label = {
                            Text(
                                if (uiState.orientation == PreviewOrientation.PORTRAIT) "عمودي" else "أفقي",
                                fontSize = 11.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (uiState.orientation == PreviewOrientation.PORTRAIT)
                                    Icons.Default.CropPortrait else Icons.Default.CropLandscape,
                                contentDescription = "تبديل الاتجاه",
                                modifier = Modifier.size(16.dp),
                                tint = BarqElectricCyan
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(containerColor = BarqNavyCard),
                        modifier = Modifier.testTag("orientation_toggle_btn")
                    )

                    // Zoom Controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BarqNavyCard)
                            .padding(horizontal = 4.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.setZoom(uiState.zoomPercent - 15) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.ZoomOut, contentDescription = "تصغير", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Text(
                            text = "${uiState.zoomPercent}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BarqElectricCyan,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        IconButton(
                            onClick = { viewModel.setZoom(uiState.zoomPercent + 15) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.ZoomIn, contentDescription = "تكبير", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    // Reload Button
                    IconButton(
                        onClick = {
                            viewModel.triggerReload()
                            webViewInstance?.reload()
                        },
                        modifier = Modifier.testTag("preview_reload_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "إعادة تحميل",
                            tint = BarqElectricCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Second Row: Quick Page Selector & Session Status
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "الصفحة:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val commonPages = listOf("login.html", "status.html", "logout.html", "error.html")
                    commonPages.forEach { page ->
                        FilterChip(
                            selected = uiState.selectedPage.equals(page, ignoreCase = true),
                            onClick = { viewModel.selectPage(page) },
                            label = { Text(page, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BarqElectricCyan.copy(alpha = 0.2f),
                                selectedLabelColor = BarqElectricCyan
                            )
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Session Switcher pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (uiState.sessionState == SessionState.LOGGED_IN)
                                    BarqElectricGreen.copy(alpha = 0.2f)
                                else
                                    BarqLightningGold.copy(alpha = 0.2f)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (uiState.sessionState == SessionState.LOGGED_IN) "حالة الجلسة: متصل" else "حالة الجلسة: غير متصل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.sessionState == SessionState.LOGGED_IN) BarqElectricGreen else BarqLightningGold
                        )
                    }
                }
            }
        }

        // 2. Interactive Preview Canvas with Simulated Device Bezel
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            val preset = uiState.devicePreset
            val isPortrait = uiState.orientation == PreviewOrientation.PORTRAIT

            val targetWidthDp = when {
                preset.widthDp == null -> null
                isPortrait -> preset.widthDp
                else -> preset.heightDp
            }

            val targetHeightDp = when {
                preset.heightDp == null -> null
                isPortrait -> preset.heightDp
                else -> preset.widthDp
            }

            val frameModifier = if (targetWidthDp != null && targetHeightDp != null) {
                Modifier
                    .width(targetWidthDp.dp.coerceAtMost(maxWidth))
                    .height(targetHeightDp.dp.coerceAtMost(maxHeight))
                    .shadow(16.dp, RoundedCornerShape(24.dp))
                    .border(3.dp, BarqNavyBorder, RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.Black)
            } else {
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
            }

            Box(modifier = frameModifier) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Simulated device notch / speaker bar (for phone frames)
                    if (preset != DevicePreset.FULL_SCREEN) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                                .background(Color(0xFF070E1A)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Camera pinhole & speaker
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF1E293B))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .width(36.dp)
                                        .height(3.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Color(0xFF1E293B))
                                )
                            }
                        }
                    }

                    // WebView Interceptor
                    AndroidView(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("hotspot_preview_webview"),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                setBackgroundColor(AndroidColor.TRANSPARENT)
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    allowFileAccess = true
                                    textZoom = uiState.zoomPercent
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                }

                                webViewClient = HotspotWebClient(
                                    repository = viewModel.repository,
                                    templateEngine = viewModel.templateEngine,
                                    getVariables = { viewModel.uiState.value.variables },
                                    getSessionState = { viewModel.uiState.value.sessionState },
                                    getLoginOutcome = { viewModel.uiState.value.loginOutcome },
                                    onSessionStateChanged = { state, err ->
                                        viewModel.setSessionState(state, err)
                                    },
                                    onDiagnosticAdded = { item ->
                                        viewModel.addDiagnostic(item)
                                    }
                                )

                                webChromeClient = HotspotChromeClient(
                                    onDiagnosticAdded = { item ->
                                        viewModel.addDiagnostic(item)
                                    }
                                )

                                loadUrl("${HotspotWebClient.BASE_HOTSPOT_URL}/${uiState.selectedPage}")
                                webViewInstance = this
                            }
                        },
                        update = { webView ->
                            webViewInstance = webView
                            webView.settings.textZoom = uiState.zoomPercent
                            val targetUrl = "${HotspotWebClient.BASE_HOTSPOT_URL}/${uiState.selectedPage}"
                            if (webView.url != targetUrl) {
                                webView.loadUrl(targetUrl)
                            }
                        }
                    )
                }
            }
        }
    }

    // Effect to reload WebView on trigger
    LaunchedEffect(uiState.reloadTrigger) {
        if (uiState.reloadTrigger > 0) {
            webViewInstance?.loadUrl("${HotspotWebClient.BASE_HOTSPOT_URL}/${uiState.selectedPage}")
        }
    }
}
