package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Html
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HotspotFileInfo
import com.example.ui.theme.BarqDanger
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqElectricGreen
import com.example.ui.theme.BarqLightningGold
import com.example.ui.theme.BarqNavyBorder
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.viewmodel.HotspotUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: HotspotUiState,
    onPickFolderClick: () -> Unit,
    onLoadDemoClick: () -> Unit,
    onNavigateToPreview: (String) -> Unit,
    onNavigateToDiagnostics: () -> Unit,
    onNavigateToLoginTest: () -> Unit,
    onNavigateToVariables: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Card - AL-BARQ NET Branding
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.35f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    BarqNavySurface,
                                    BarqNavyCard.copy(alpha = 0.9f),
                                    BarqRoyalBlue.copy(alpha = 0.2f)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "AL-BARQ NET",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BarqElectricCyan,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Hotspot Simulator & Diagnostic Engine",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(BarqElectricCyan, BarqRoyalBlue)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Al-Barq Bolt",
                                    tint = Color(0xFF030A16),
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "محاكي احترافي لبيئة MikroTik RouterOS لتشغيل وفحص صفحات تسجيل الدخول بالمتغيرات والمسارات والـ CHAP دون الحاجة لراوتر حقيقي.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Security guarantee badge (Non-destructive)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF001B2E))
                                .border(1.dp, BarqElectricGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "أمان الملفات",
                                tint = BarqElectricGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "حماية كاملة: المعاينة محلية دون تعديل أو استبدال ملفات المصدر الأصلية.",
                                fontSize = 11.sp,
                                color = BarqElectricGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // 2. Folder Selection & Project Management Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = "مجلد المشروع",
                            tint = BarqElectricCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مشروع صفحات الهوتسبوت",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Active Folder Name
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(BarqNavyCard)
                            .border(1.dp, BarqNavyBorder, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "المجلد الحالي:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = uiState.folderName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (uiState.isBuiltinDemo) BarqLightningGold else BarqElectricCyan,
                                    modifier = Modifier.weight(1f)
                                )
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = BarqElectricCyan
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary Action Button: Pick Folder from device (SAF)
                    Button(
                        onClick = onPickFolderClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("pick_hotspot_folder_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BarqRoyalBlue,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = "اختيار مجلد",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختيار مجلد الهوتسبوت من الهاتف",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Secondary Action Button: Load Built-in Demo
                    OutlinedButton(
                        onClick = onLoadDemoClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("load_demo_project_btn"),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "النموذج التجريبي",
                            tint = BarqElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "استخدام النموذج التجريبي لشبكة البرق نت",
                            color = BarqElectricCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 3. Quick Actions Cards
        item {
            Text(
                text = "الأدوات السريعة",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                maxItemsInEachRow = 2
            ) {
                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    title = "معاينة الصفحة",
                    subtitle = uiState.selectedPage,
                    icon = Icons.Default.Visibility,
                    accentColor = BarqElectricCyan,
                    tag = "quick_preview_card",
                    onClick = { onNavigateToPreview(uiState.selectedPage) }
                )

                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    title = "فحص وتشخيص",
                    subtitle = "${uiState.diagnostics.size} تنبيهات مرصودة",
                    icon = Icons.Default.Code,
                    accentColor = BarqLightningGold,
                    tag = "quick_diagnostics_card",
                    onClick = onNavigateToDiagnostics
                )

                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    title = "اختبار الدخول",
                    subtitle = if (uiState.sessionState == com.example.model.SessionState.LOGGED_IN) "جلسة نشطة" else "تسجيل تجريبي",
                    icon = Icons.Default.PlayArrow,
                    accentColor = BarqElectricGreen,
                    tag = "quick_login_test_card",
                    onClick = onNavigateToLoginTest
                )

                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    title = "متغيرات المحاكاة",
                    subtitle = "تخصيص IP، MAC، الروابط",
                    icon = Icons.Default.Settings,
                    accentColor = BarqRoyalBlue,
                    tag = "quick_variables_card",
                    onClick = onNavigateToVariables
                )
            }
        }

        // 4. File Tree Explorer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.InsertDriveFile,
                                contentDescription = "الملفات",
                                tint = BarqElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "مستكشف ملفات الهوتسبوت",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Text(
                            text = "${uiState.fileTree.size} ملف/مجلد",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "اضغط على أي ملف HTML لمعاينته مباشرة في المحاكي:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiState.fileTree.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "المجلد فارغ أو لم يتم اختيار مجلد بعد.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        uiState.fileTree.forEach { file ->
                            FileTreeItemRow(
                                file = file,
                                selectedPage = uiState.selectedPage,
                                onHtmlClick = { path ->
                                    onNavigateToPreview(path)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(90.dp)
            .clickable(onClick = onClick)
            .testTag(tag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
fun FileTreeItemRow(
    file: HotspotFileInfo,
    selectedPage: String,
    level: Int = 0,
    onHtmlClick: (String) -> Unit
) {
    val isSelected = file.path.equals(selectedPage, ignoreCase = true)

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (level * 16).dp, top = 4.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) BarqRoyalBlue.copy(alpha = 0.25f) else Color.Transparent)
            .clickable(enabled = file.isHtml) {
                if (file.isHtml) onHtmlClick(file.path)
            }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        val icon = when {
            file.isDirectory -> Icons.Default.Folder
            file.isHtml -> Icons.Default.Html
            file.name.endsWith(".js") -> Icons.Default.Code
            file.name.endsWith(".css") -> Icons.Default.InsertDriveFile
            else -> Icons.Default.InsertDriveFile
        }

        val tint = when {
            file.isDirectory -> BarqElectricCyan
            file.isHtml -> BarqLightningGold
            file.name.endsWith(".js") -> BarqElectricGreen
            file.name.endsWith(".css") -> Color(0xFF48CAE4)
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        }

        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = file.name,
                    fontSize = 13.sp,
                    fontWeight = if (file.isHtml) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) BarqElectricCyan else MaterialTheme.colorScheme.onSurface
                )
                if (file.name.equals("login.html", ignoreCase = true)) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(BarqElectricGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "صفحة الدخول",
                            fontSize = 9.sp,
                            color = BarqElectricGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (!file.isDirectory && file.size > 0) {
                Text(
                    text = formatFileSize(file.size),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (file.isHtml) {
            Icon(
                imageVector = Icons.Default.Visibility,
                contentDescription = "معاينة",
                tint = if (isSelected) BarqElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
        }
    }

    if (file.isDirectory && file.children.isNotEmpty()) {
        file.children.forEach { child ->
            FileTreeItemRow(
                file = child,
                selectedPage = selectedPage,
                level = level + 1,
                onHtmlClick = onHtmlClick
            )
        }
    }
}

private fun formatFileSize(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes.toDouble() / (1024 * 1024))
        bytes >= 1024 -> String.format("%.1f KB", bytes.toDouble() / 1024)
        else -> "$bytes B"
    }
}
