package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HotspotVariables
import com.example.ui.theme.BarqElectricCyan
import com.example.ui.theme.BarqElectricGreen
import com.example.ui.theme.BarqLightningGold
import com.example.ui.theme.BarqNavyBorder
import com.example.ui.theme.BarqNavyCard
import com.example.ui.theme.BarqNavySurface
import com.example.ui.theme.BarqRoyalBlue
import com.example.viewmodel.HotspotUiState
import com.example.viewmodel.HotspotViewModel

@Composable
fun VariablesScreen(
    viewModel: HotspotViewModel,
    uiState: HotspotUiState
) {
    val context = LocalContext.current
    val currentVars = uiState.variables

    var ip by remember(currentVars) { mutableStateOf(currentVars.ip) }
    var mac by remember(currentVars) { mutableStateOf(currentVars.mac) }
    var username by remember(currentVars) { mutableStateOf(currentVars.username) }
    var identity by remember(currentVars) { mutableStateOf(currentVars.identity) }
    var serverName by remember(currentVars) { mutableStateOf(currentVars.serverName) }
    var interfaceName by remember(currentVars) { mutableStateOf(currentVars.interfaceName) }
    var linkOrig by remember(currentVars) { mutableStateOf(currentVars.linkOrig) }
    var uptime by remember(currentVars) { mutableStateOf(currentVars.uptime) }
    var sessionTimeLeft by remember(currentVars) { mutableStateOf(currentVars.sessionTimeLeft) }
    var bytesInStr by remember(currentVars) { mutableStateOf(currentVars.bytesIn.toString()) }
    var bytesOutStr by remember(currentVars) { mutableStateOf(currentVars.bytesOut.toString()) }
    var remainBytesStr by remember(currentVars) { mutableStateOf(currentVars.remainBytesTotal.toString()) }
    var trialEnabled by remember(currentVars) { mutableStateOf(currentVars.trialEnabled) }
    var chapId by remember(currentVars) { mutableStateOf(currentVars.chapId) }
    var chapChallenge by remember(currentVars) { mutableStateOf(currentVars.chapChallenge) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.3f))
        ) {
            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = BarqElectricCyan, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "قيم المحاكاة: يتم حقن هذه القيم تلقائياً في قوالب MikroTik عبر المتغيرات مثل \$(ip) و \$(mac) و \$(identity). جميعها بيانات تجريبية محلية.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                )
            }
        }

        // Network & Client Identity
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "بيانات المشترك والشبكة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BarqElectricCyan
                )

                VariableTextField(
                    label = "عنوان IP (\$(ip))",
                    value = ip,
                    onValueChange = { ip = it },
                    tag = "input_var_ip"
                )

                VariableTextField(
                    label = "عنوان MAC (\$(mac))",
                    value = mac,
                    onValueChange = { mac = it },
                    tag = "input_var_mac"
                )

                VariableTextField(
                    label = "اسم المشترك (\$(username))",
                    value = username,
                    onValueChange = { username = it },
                    tag = "input_var_username"
                )
            }
        }

        // Router & Server Identifiers
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "إعدادات الراوتر والمخدم",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BarqElectricCyan
                )

                VariableTextField(
                    label = "اسم الراوتر (\$(identity))",
                    value = identity,
                    onValueChange = { identity = it },
                    tag = "input_var_identity"
                )

                VariableTextField(
                    label = "اسم المخدم (\$(server-name))",
                    value = serverName,
                    onValueChange = { serverName = it },
                    tag = "input_var_server_name"
                )

                VariableTextField(
                    label = "اسم المنفذ (\$(interface-name))",
                    value = interfaceName,
                    onValueChange = { interfaceName = it },
                    tag = "input_var_interface_name"
                )

                VariableTextField(
                    label = "الرابط المطلوب مسبقاً (\$(link-orig))",
                    value = linkOrig,
                    onValueChange = { linkOrig = it },
                    tag = "input_var_link_orig"
                )
            }
        }

        // Session & Quota Variables
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BarqNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BarqNavyBorder)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "بيانات الجلسة والرصيد",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = BarqElectricCyan
                )

                VariableTextField(
                    label = "مدة الاتصال (\$(uptime))",
                    value = uptime,
                    onValueChange = { uptime = it },
                    tag = "input_var_uptime"
                )

                VariableTextField(
                    label = "الوقت المتبقي (\$(session-time-left))",
                    value = sessionTimeLeft,
                    onValueChange = { sessionTimeLeft = it },
                    tag = "input_var_session_time_left"
                )

                VariableTextField(
                    label = "البيانات المحملة تنزيل بالبايت (\$(bytes-in))",
                    value = bytesInStr,
                    onValueChange = { bytesInStr = it },
                    tag = "input_var_bytes_in"
                )

                VariableTextField(
                    label = "البيانات المرفوعة رفع بالبايت (\$(bytes-out))",
                    value = bytesOutStr,
                    onValueChange = { bytesOutStr = it },
                    tag = "input_var_bytes_out"
                )

                VariableTextField(
                    label = "الرصيد المتبقي بالبايت (\$(remain-bytes-total))",
                    value = remainBytesStr,
                    onValueChange = { remainBytesStr = it },
                    tag = "input_var_remain_bytes"
                )

                // Free trial toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BarqNavyCard)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "تفعيل التجربة المجانية (\$(if trial))",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "يتحكم في إظهار زر التجربة المجانية إذا كانت الصفحة تدعمه",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = trialEnabled,
                        onCheckedChange = { trialEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BarqElectricCyan,
                            checkedTrackColor = BarqRoyalBlue
                        )
                    )
                }
            }
        }

        // Action Buttons: Save & Reset
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    val updated = currentVars.copy(
                        ip = ip,
                        mac = mac,
                        username = username,
                        identity = identity,
                        serverName = serverName,
                        interfaceName = interfaceName,
                        linkOrig = linkOrig,
                        uptime = uptime,
                        sessionTimeLeft = sessionTimeLeft,
                        bytesIn = bytesInStr.toLongOrNull() ?: currentVars.bytesIn,
                        bytesOut = bytesOutStr.toLongOrNull() ?: currentVars.bytesOut,
                        remainBytesTotal = remainBytesStr.toLongOrNull() ?: currentVars.remainBytesTotal,
                        trialEnabled = trialEnabled,
                        chapId = chapId,
                        chapChallenge = chapChallenge
                    )
                    viewModel.updateVariables(updated)
                    Toast.makeText(context, "تم حفظ وتطبيق المتغيرات على المعاينة", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("save_variables_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BarqRoyalBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ وتطبيق", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            OutlinedButton(
                onClick = {
                    viewModel.resetVariablesToDefault()
                    Toast.makeText(context, "تمت استعادة القيم الافتراضية", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("reset_variables_btn"),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BarqElectricCyan.copy(alpha = 0.5f))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = BarqElectricCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إعادة للافتراضي", color = BarqElectricCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun VariableTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    tag: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BarqElectricCyan,
            unfocusedBorderColor = BarqNavyBorder,
            focusedContainerColor = BarqNavyCard,
            unfocusedContainerColor = BarqNavyCard
        )
    )
}
