package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BarqElectricCyan,
    onPrimary = Color(0xFF031020),
    primaryContainer = BarqRoyalBlue,
    onPrimaryContainer = Color.White,
    secondary = BarqCyanSoft,
    onSecondary = Color(0xFF031020),
    tertiary = BarqLightningGold,
    background = BarqNavyBackground,
    onBackground = BarqTextPrimary,
    surface = BarqNavySurface,
    onSurface = BarqTextPrimary,
    surfaceVariant = BarqNavyCard,
    onSurfaceVariant = BarqTextSecondary,
    outline = BarqNavyBorder,
    error = BarqDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = BarqRoyalBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = BarqLightPrimary,
    onSecondary = Color.White,
    tertiary = BarqLightningGold,
    background = BarqLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = BarqLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF475569),
    outline = BarqLightBorder,
    error = BarqDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to stunning Al-Barq dark tech mode
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
