package com.example.data

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.example.model.HotspotFileInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * Repository for accessing hotspot files either from the built-in demo assets
 * or from a user-selected SAF (Storage Access Framework) folder.
 * Operates purely in read-only mode to preserve user production files intact.
 */
class HotspotRepository(private val context: Context) {

    enum class SourceType {
        BUILTIN_DEMO,
        USER_SAF_FOLDER
    }

    private var currentSourceType: SourceType = SourceType.BUILTIN_DEMO
    private var currentFolderUri: Uri? = null
    private var currentFolderName: String = "النموذج التجريبي لشبكة البرق نت"
    private var cachedDocumentRoot: DocumentFile? = null

    // Cache of scanned files: relative path -> DocumentFile
    private val safFileCache = mutableMapOf<String, DocumentFile>()

    suspend fun loadBuiltinDemo(): List<HotspotFileInfo> = withContext(Dispatchers.IO) {
        currentSourceType = SourceType.BUILTIN_DEMO
        currentFolderUri = null
        currentFolderName = "النموذج التجريبي لشبكة البرق نت (داخلي)"
        safFileCache.clear()

        val sampleFiles = listOf(
            "login.html",
            "status.html",
            "logout.html",
            "error.html",
            "md5.js",
            "style.css"
        )

        sampleFiles.map { name ->
            val size = try {
                context.assets.open("sample_hotspot/$name").use { it.available().toLong() }
            } catch (_: Exception) {
                0L
            }
            HotspotFileInfo(
                name = name,
                path = name,
                isDirectory = false,
                size = size,
                isHtml = name.endsWith(".html")
            )
        }
    }

    suspend fun setFolderUri(uri: Uri): Pair<String, List<HotspotFileInfo>> = withContext(Dispatchers.IO) {
        currentSourceType = SourceType.USER_SAF_FOLDER
        currentFolderUri = uri
        safFileCache.clear()

        val rootDoc = DocumentFile.fromTreeUri(context, uri)
            ?: throw IllegalArgumentException("تعذر فتح المجلد المختار عبر SAF")

        cachedDocumentRoot = rootDoc
        currentFolderName = rootDoc.name ?: "مجلد الهوتسبوت"

        // Build file tree recursively and index relative paths
        val files = scanDocumentFile(rootDoc, "")
        Pair(currentFolderName, files)
    }

    private fun scanDocumentFile(dir: DocumentFile, parentPath: String): List<HotspotFileInfo> {
        val result = mutableListOf<HotspotFileInfo>()
        val list = dir.listFiles()

        for (item in list) {
            val name = item.name ?: continue
            val relativePath = if (parentPath.isEmpty()) name else "$parentPath/$name"

            if (item.isDirectory) {
                safFileCache[relativePath.lowercase()] = item
                val children = scanDocumentFile(item, relativePath)
                result.add(
                    HotspotFileInfo(
                        name = name,
                        path = relativePath,
                        isDirectory = true,
                        children = children
                    )
                )
            } else {
                safFileCache[relativePath.lowercase()] = item
                // Also index by just filename if in root
                if (parentPath.isEmpty()) {
                    safFileCache[name.lowercase()] = item
                }
                result.add(
                    HotspotFileInfo(
                        name = name,
                        path = relativePath,
                        isDirectory = false,
                        size = item.length(),
                        isHtml = name.endsWith(".html", ignoreCase = true)
                    )
                )
            }
        }
        return result
    }

    fun getSourceType(): SourceType = currentSourceType
    fun getFolderName(): String = currentFolderName
    fun getFolderUri(): Uri? = currentFolderUri

    /**
     * Reads a file as String.
     * Never alters original file.
     */
    suspend fun readFileContent(relativePath: String): String? = withContext(Dispatchers.IO) {
        val inputStream = openFileInputStream(relativePath) ?: return@withContext null
        try {
            inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Opens an InputStream for the given relative path.
     * Supports relative resolution (e.g. "img/logo.png", "css/style.css", "/status.html").
     */
    fun openFileInputStream(rawPath: String): InputStream? {
        val cleanPath = rawPath.trim().removePrefix("/").trim()

        if (currentSourceType == SourceType.BUILTIN_DEMO) {
            return try {
                context.assets.open("sample_hotspot/$cleanPath")
            } catch (_: Exception) {
                // If requested without extension or subfolder match
                null
            }
        }

        // User SAF folder lookup
        val lower = cleanPath.lowercase()
        val docFile = safFileCache[lower]
            ?: safFileCache[cleanPath.substringAfterLast("/").lowercase()]
            ?: findByPathFallback(cleanPath)

        return if (docFile != null && docFile.isFile) {
            try {
                context.contentResolver.openInputStream(docFile.uri)
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }
    }

    private fun findByPathFallback(path: String): DocumentFile? {
        val root = cachedDocumentRoot ?: return null
        val segments = path.split("/").filter { it.isNotEmpty() }
        var current: DocumentFile = root
        for (seg in segments) {
            val child = current.findFile(seg) ?: return null
            current = child
        }
        return current
    }

    /**
     * Guesses the MIME type from the file extension.
     */
    fun getMimeType(path: String): String {
        val clean = path.substringBefore("?").substringBefore("#")
        val ext = clean.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html"
            "css" -> "text/css"
            "js" -> "application/javascript"
            "json" -> "application/json"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "webp" -> "image/webp"
            "ico" -> "image/x-icon"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "eot" -> "application/vnd.ms-fontobject"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }
}
